<?php

error_reporting(0);

$server="localhost";   
$user="root";
$pass="";
$database="cp_2";

$conn = mysqli_connect($server,$user,$pass,$database);


?>